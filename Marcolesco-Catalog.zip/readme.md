A simple photo gallery web app to demonstrate the creation of a web server in Node.  The photos in the images folder were downloaded from [pixabay.com](pixabay.com) and are in the public domain.
